import os
import cv2
from glob import glob
import numpy as np
import pandas as pd
import popup, result
import Confusion_matrix
import tensorflow as tf
from other.root import *
from other.ab import *
from AlexNet import alexnet_
from colorama import Fore, init
from comparision import ab_comp
from GoogleNet import GoogLeNet_
from Squeezenet import csqueezenet_
from tensorflow.keras import Model
from matplotlib import pyplot as plt
from LinkNet import linknet_, linknet_lr
from Augmentation_process import augment_process
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from sklearn.model_selection import train_test_split
from numpy import mean, median, std, min, max, array as ar
from tensorflow.keras.layers import Dense, Dropout, Input, Conv2D, MaxPooling2D, Flatten, GlobalAveragePooling2D, concatenate,\
    LSTM, Bidirectional, GRU, Conv1D, MaxPooling1D
feat_extraction = False
run = 1


def full_analysis():
    if feat_extraction:
        def gaussian_weight(x, y, sigma):
            """Compute the Gaussian weight based on Euclidean distance"""
            distance = np.sqrt(x ** 2 + y ** 2)  # Euclidean distance from the center
            exp_term = np.exp(-distance ** 2 / (2 * (sigma ** 2)))
            first_term = 1 / (2 * np.pi * (sigma ** 2))
            return first_term * exp_term

        def weighted_mean(window, sigma):
            """Compute the weighted mean of the window using Gaussian weights"""
            # Get the shape of the window
            height, width = window.shape
            # Create a weight matrix based on the Gaussian function
            weights = np.zeros((height, width))
            center = (height // 2, width // 2)  # Center pixel coordinates
            # Compute weights for each pixel in the window
            for i in range(height):
                for j in range(width):
                    weights[i, j] = gaussian_weight(i - center[0], j - center[1], sigma)
            # Normalize the weights so they sum to 1
            weights /= np.sum(weights)
            # Compute the weighted mean
            weighted_sum = np.sum(window * weights)
            return weighted_sum

        def dynamic_alpha(window, current_pixel, beta):
            """Compute adaptive alpha value"""
            avg = weighted_mean(window, sigma=np.random.random())  # Weighted mean instead of simple mean
            std = np.std(window)
            gamma = np.random.random()
            if std < 1e-6:  # Avoid division by zero
                return 0.0
            z = beta * (abs(current_pixel - avg) / std - gamma)
            return z

        def adaptive_weighted_medavg(image, window_size=3):
            """Enhanced MedAvg filter with dynamic weighting using Gaussian weights"""
            pad = window_size // 2
            padded = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
            filtered = np.zeros_like(image)
            for i in range(pad, padded.shape[0] - pad):
                for j in range(pad, padded.shape[1] - pad):
                    window = padded[i - pad:i + pad + 1, j - pad:j + pad + 1]
                    current = padded[i, j]
                    # Compute weighted mean and median
                    avg = weighted_mean(window, sigma=np.random.random())
                    median = np.median(window)
                    beta = np.random.random()
                    # If current pixel > weighted mean, apply dynamic weighting
                    if current > avg:
                        alpha = dynamic_alpha(window, current, beta)
                        filtered[i - pad, j - pad] = alpha * median + (1 - alpha) * current
                    else:
                        filtered[i - pad, j - pad] = current
            return filtered

        def medav_filter(image, window_size=3):
            """
            Implementation of the Medav Filter - a combination of median and average filters

            Parameters:
            - image: Input image (grayscale or color)
            - window_size: Size of the filtering window (must be odd)

            Returns:
            - Filtered image
            """
            # Validate window size
            if window_size % 2 == 0:
                raise ValueError("Window size must be odd")

            # Pad the image to handle borders
            pad = window_size // 2
            padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)

            # Initialize output image
            filtered_image = np.zeros_like(image)

            # Get image dimensions
            if len(image.shape) == 2:  # Grayscale
                rows, cols = image.shape
                channels = 1
            else:  # Color
                rows, cols, channels = image.shape
            # Process each pixel
            for i in range(pad, rows + pad):
                for j in range(pad, cols + pad):
                    for c in range(channels) if channels > 1 else [0]:
                        # Extract the neighborhood window
                        if channels == 1:
                            window = padded_image[i - pad:i + pad + 1, j - pad:j + pad + 1]
                            current_pixel = padded_image[i, j]
                        else:
                            window = padded_image[i - pad:i + pad + 1, j - pad:j + pad + 1, c]
                            current_pixel = padded_image[i, j, c]
                        # Step 2: Calculate average value of the window
                        V_avg = np.mean(window)
                        # Step 3: Apply Medav filter logic
                        if current_pixel > V_avg:
                            # Replace with median if pixel is greater than average
                            filtered_value = np.median(window)
                        else:
                            # Keep original value otherwise
                            filtered_value = current_pixel
                        # Store the result
                        if channels == 1:
                            filtered_image[i - pad, j - pad] = filtered_value
                        else:
                            filtered_image[i - pad, j - pad, c] = filtered_value
            return filtered_image

        def read_data():
            print('##-----Reading Dataset-----##')
            DATASET_PATH = 'Dataset/Original Image/'
            fresh_leaf = glob(os.path.join(DATASET_PATH, "Fresh Leaf", "*"))
            downy_leaf = glob(os.path.join(DATASET_PATH, "Downy mildew", "*"))
            gray_leaf = glob(os.path.join(DATASET_PATH, "Gray mold", "*"))
            scar_leaf = glob(os.path.join(DATASET_PATH, "Leaf scars", "*"))

            img, multi_label = [], []
            print('#---- Fresh Leaf Images ----#')
            for t_img_path in fresh_leaf:
                im_ = cv2.imread(t_img_path)
                imgg = cv2.resize(im_, (512, 512))
                img.append(imgg)
                multi_label.append(0)
            print('#---- Downy Leaf Images ----#')
            for t_img_path in downy_leaf:
                im_ = cv2.imread(t_img_path)
                imgg = cv2.resize(im_, (512, 512))
                img.append(imgg)
                multi_label.append(1)
            print('#---- Gray Leaf Images ----#')
            for t_img_path in gray_leaf:
                im_ = cv2.imread(t_img_path)
                imgg = cv2.resize(im_, (512, 512))
                img.append(imgg)
                multi_label.append(2)
            print('#---- Scar Leaf Images ----#')
            for t_img_path in scar_leaf:
                im_ = cv2.imread(t_img_path)
                imgg = cv2.resize(im_, (512, 512))
                img.append(imgg)
                multi_label.append(3)
            o_img = np.array(img)
            mul_lab = np.array(multi_label)
            print('#---- Augmentation Process ----#')
            c0 = np.where(mul_lab == 0)[0]
            c1 = np.where(mul_lab == 1)[0]
            c2 = np.where(mul_lab == 2)[0]
            c3 = np.where(mul_lab == 3)[0]
            im0 = o_img[c0]
            im1 = o_img[c1]
            im2 = o_img[c2]
            im3 = o_img[c3]
            lab0 = mul_lab[c0]
            lab1 = mul_lab[c1]
            lab2 = mul_lab[c2]
            lab3 = mul_lab[c3]
            a_img0, a_lab0 = augment_process(im0, lab0, cond='class0')
            a_img1, a_lab1 = augment_process(im1, lab1, cond='class1')
            a_img2, a_lab2 = augment_process(im2, lab2, cond='class2')
            a_img3, a_lab3 = augment_process(im3, lab3, cond='class3')
            aug_img = np.concatenate((a_img0, a_img1, a_img2, a_img3), axis=0)
            aug_lab = np.concatenate((a_lab0, a_lab1, a_lab2, a_lab3), axis=0)
            p_img, ip_img = [], []
            print('##------Preprocessing-------##')
            for im in aug_img:
                im = cv2.resize(im, (64, 64))
                pre_img = medav_filter(im)
                ipre_img = adaptive_weighted_medavg(im)
                p_img.append(pre_img)
                ip_img.append(ipre_img)
            pre_img = np.array(p_img)
            imp_pimg = np.array(ip_img)
            np.save('label', aug_lab)
            np.save('org_img', aug_img)
            np.save('pre_img', pre_img)
            np.save('imp_pimg', imp_pimg)
        # read_data()

        pre_img = np.load('pre_img.npy', allow_pickle=True)
        imp_pimg = np.load('imp_pimg.npy', allow_pickle=True)
        gt = np.load('gt_img.npy', allow_pickle=True)

        print('#-----UNet Segmentation-----#')
        ###***Segmentation***###
        from UNet_Segmentation import Unet_seg, Imp_unet
        def seg_process():
            conv_segimg = [Unet_seg(i, img1) for idx, (i, img1) in enumerate(zip(pre_img, gt))]
            # np.save('conv_seg', np.array(conv_segimg))
            imp_segimg = [Imp_unet(i, img1) for idx, (i, img1) in enumerate(zip(imp_pimg, gt))]
            # np.save('imp_seg', np.array(imp_segimg))
            imp_segimg1 = [Imp_unet(i, img1) for idx, (i, img1) in enumerate(zip(pre_img, gt))]
            # np.save('imp_seg1', np.array(imp_segimg1))
        # segment = seg_process()

        conv_seg = np.load('conv_seg.npy', allow_pickle=True)
        imp_seg = np.load('imp_seg.npy', allow_pickle=True)
        imp_seg1 = np.load('imp_seg1.npy', allow_pickle=True)

        print('###-----Feature Extraction-----###')
        print('#-----PHOG Feature-----#')
        def PHOG_feature():
            from PHOG import conventional_phog
            segimg = [imp_seg, conv_seg, imp_seg1]
            phog_feat = []
            for i in range(len(segimg)):
                seg_img = segimg[i]
                phog = []
                for img in seg_img:
                    phog.append(conventional_phog(img))
                phog_feat.append(np.array(phog))
            return phog_feat

        # phog_featt = PHOG_feature()
        # np.save('phog_feat', phog_featt[0])
        # np.save('phog_feat1', phog_featt[1])
        # np.save('phog_feat2', phog_featt[2])
        phog_feat = np.load('phog_feat.npy', allow_pickle=True)
        phog_feat1 = np.load('phog_feat1.npy', allow_pickle=True)
        phog_feat2 = np.load('phog_feat2.npy', allow_pickle=True)

        print('#------LBP Feature------#')
        def get_pixel(Img, center, x, y):
            new_value = 0
            try:
                if Img[x][y] >= center:
                    new_value = 1
            except:
                pass
            return new_value

        def lbp_calculated_pixel(Img, x, y):
            '''
             64 | 128 |   1
            ----------------
             32 |   0 |   2
            ----------------
             16 |   8 |   4
            '''
            center = Img[x][y]
            val_ar = []
            val_ar.append(get_pixel(Img, center, x - 1, y + 1))  # top_right
            val_ar.append(get_pixel(Img, center, x, y + 1))  # right
            val_ar.append(get_pixel(Img, center, x + 1, y + 1))  # bottom_right
            val_ar.append(get_pixel(Img, center, x + 1, y))  # bottom
            val_ar.append(get_pixel(Img, center, x + 1, y - 1))  # bottom_left
            val_ar.append(get_pixel(Img, center, x, y - 1))  # left
            val_ar.append(get_pixel(Img, center, x - 1, y - 1))  # top_left
            val_ar.append(get_pixel(Img, center, x - 1, y))  # top

            power_val = [1, 2, 4, 8, 16, 32, 64, 128]
            val = 0
            for i in range(len(val_ar)):
                val += val_ar[i] * power_val[i]
            return val

        def lbp_feature():
            im = [imp_seg, conv_seg, imp_seg1]
            lbp = []
            for im_ in im:
                imglbp = np.zeros((im_.shape[0], 10))
                for ii in range(0, len(im_)):
                    lbpout = np.zeros((np.shape(im_[ii])[0], np.shape(im_[ii])[1]), np.uint8)
                    for i in range(0, np.shape(im_[ii])[0]):
                        for j in range(0, np.shape(im_[ii])[1]):
                            lbpout[i,j] = lbp_calculated_pixel(im_[ii], i, j)
                    imglbp[ii,:] = np.histogram(lbpout)[0]
                lbp.append(imglbp)
            return lbp

        # lbp_fet = lbp_feature()
        # np.save('lbp_feat', lbp_fet[0])
        # np.save('lbp_feat1', lbp_fet[1])
        # np.save('lbp_feat2', lbp_fet[2])
        lbp_feat = np.load('lbp_feat.npy', allow_pickle=True)
        lbp_feat1 = np.load('lbp_feat1.npy', allow_pickle=True)
        lbp_feat2 = np.load('lbp_feat2.npy', allow_pickle=True)

        print('#-----FFT Feature-----#')
        def FFT_feature():
            from FFT import fft_features
            segimg = [imp_seg, conv_seg, imp_seg1]
            fft_feat = []
            for seg_img in segimg:
                fft = []
                for img in seg_img:
                    fft.append(fft_features(img))
                fft_feat.append(np.array(fft))
            return fft_feat

        # fft_featt = FFT_feature()
        # np.save('fft_feat', fft_featt[0])
        # np.save('fft_feat1', fft_featt[1])
        # np.save('fft_feat2', fft_featt[2])
        fft_feat = np.load('fft_feat.npy', allow_pickle=True)
        fft_feat1 = np.load('fft_feat1.npy', allow_pickle=True)
        fft_feat2 = np.load('fft_feat2.npy', allow_pickle=True)

        print('#-----DFT Feature-----#')
        def DFT_feature():
            from DFT import dft_features
            segimg = [imp_seg, conv_seg, imp_seg1]
            dft_feat = []
            for seg_img in segimg:
                dft = []
                for img in seg_img:
                    dft.append(dft_features(img))
                dft_feat.append(np.array(dft))
            return dft_feat

        # dft_featt = DFT_feature()
        # np.save('dft_feat', dft_featt[0])
        # np.save('dft_feat1', dft_featt[1])
        # np.save('dft_feat2', dft_featt[2])
        dft_feat = np.load('dft_feat.npy', allow_pickle=True)
        dft_feat1 = np.load('dft_feat1.npy', allow_pickle=True)
        dft_feat2 = np.load('dft_feat2.npy', allow_pickle=True)

        #---Final Feature----#
        f1 = np.concatenate((lbp_feat, phog_feat, dft_feat, fft_feat), axis=1)## proposed
        f2 = np.concatenate((lbp_feat1, phog_feat1, dft_feat1, fft_feat1), axis=1)## conv segmentation
        f3 = np.concatenate((lbp_feat2, phog_feat2, dft_feat2, fft_feat2), axis=1)## conv preprocessing
        f4 = imp_seg ## without feature extraction
        np.save('FEAT', f1)
        np.save('Feat1', f2)
        np.save('Feat2', f3)
        np.save('Feat3', f4)

    def stat_analysis(xx):
        mn = np.mean(xx, axis=0).reshape(-1, 1)
        mdn = np.median(xx, axis=0).reshape(-1, 1)
        std_dev = np.std(xx, axis=0).reshape(-1, 1)
        min = np.min(xx, axis=0).reshape(-1, 1)
        mx = np.max(xx, axis=0).reshape(-1, 1)
        return np.concatenate((mn, mdn, std_dev, min, mx), axis=1)

    def Bspr1():
        print('Bspr1')
        train_data = X_train.astype('float32')
        test_data = X_test.astype('float32')
        train_data = train_data / np.max(train_data)
        test_data = test_data / np.max(test_data)
        train_x = train_data[:, :, np.newaxis]
        train_y = tf.keras.utils.to_categorical(Y_train)
        test_x = test_data[:, :, np.newaxis]
        test_y = tf.keras.utils.to_categorical(Y_test)
        verbose, epochs, batch_size = 0, 2, 32
        n_timesteps, n_features, n_outputs = train_x.shape[1], train_x.shape[2], train_y.shape[1]
        model = Sequential()
        model.add(Conv1D(32, kernel_size=3, activation='relu', input_shape=(n_timesteps, n_features)))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Conv1D(32, kernel_size=1, activation='relu'))
        model.add(Conv1D(64, kernel_size=1, activation='relu'))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Conv1D(32, kernel_size=1, activation='relu'))
        model.add(Conv1D(64, kernel_size=1, activation='relu'))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Flatten())
        model.add(Dense(100, activation='relu'))
        model.add(Dense(ln, activation='softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        print(model.summary())
        model.fit(train_x, train_y, epochs=2, batch_size=batch_size, verbose=0)
        y_predict = np.argmax(model.predict(test_x), axis=-1)
        pred = arraY_(y_predict, axis=6)
        return Confusion_matrix.multi_confu_matrix(Y_test.reshape(-1, 1), pred), pred

    def Bspr2():
        print('Bspr2')
        ln = len(set(Y_train.flatten()))
        Lab = np.concatenate((Y_train, Y_test))
        cnn_X_train = X_train.reshape((X_train.shape[0], 1, 1, X_train.shape[1]))
        cnn_X_test = X_test.reshape((X_test.shape[0], 1, 1, X_test.shape[1]))

        model = Sequential()
        model.add(Conv2D(16, (1, 1), padding='valid', input_shape=cnn_X_train[0].shape, activation='relu'))
        model.add(MaxPooling2D(pool_size=(1, 1)))
        model.add(Dropout(0.2))

        model.add(Conv2D(32, (1, 1), padding='valid', activation='relu'))
        model.add(MaxPooling2D(pool_size=(1, 1)))
        model.add(Dropout(0.2))

        model.add(Conv2D(64, (1, 1), padding='valid', activation='relu'))
        model.add(MaxPooling2D(pool_size=(1, 1)))
        model.add(Dropout(0.2))

        model.add(Flatten())
        model.add(Dense(ln, activation='softmax'))

        model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        model.fit(cnn_X_train, Y_train, epochs=2, batch_size=32, verbose=0)
        print(model.summary())
        # pred = model.predict(cnn_X_test)
        pred = arraY_(np.argmax(model.predict(cnn_X_test), axis=-1), axis=7)
        return Confusion_matrix.multi_confu_matrix(Y_test.reshape(-1, 1), pred), pred

    def Bilstm():
        np.random.seed(7)
        train_X = X_train.reshape(-1, X_train.shape[1], 1)
        test_X = X_test.reshape(-1, X_train.shape[1], 1)
        model = Sequential()
        model.add(LSTM(128, input_shape=(train_X.shape[1], train_X.shape[2]), return_sequences=True))
        model.add(Bidirectional(LSTM(128)))
        model.add(Dropout(0.2))
        # number of features on the output
        model.add(Dropout(0.2))
        ln = len(np.unique(Y_train))
        model.add(Dense(ln, activation='sigmoid'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])
        model.summary()
        model.fit(train_X, Y_train, batch_size=128, epochs=1, verbose=0)
        pred = np.argmax(model.predict(test_X), axis=-1)
        pred = arraY_(pred, axis=3)
        return Confusion_matrix.multi_confu_matrix(Y_test.reshape(-1, 1), pred), pred

    def DCNN():
        print('DCNN')
        ln = len(set(Y_train.flatten()))
        Lab = np.concatenate((Y_train, Y_test))
        cnn_X_train = X_train.reshape((X_train.shape[0], 1, 1, X_train.shape[1]))
        cnn_X_test = X_test.reshape((X_test.shape[0], 1, 1, X_test.shape[1]))

        model = Sequential()
        model.add(Conv2D(16, (1, 1), padding='valid', input_shape=cnn_X_train[0].shape, activation='relu'))
        model.add(MaxPooling2D(pool_size=(1, 1)))
        model.add(Dropout(0.2))

        model.add(Conv2D(32, (1, 1), padding='valid', activation='relu'))
        model.add(MaxPooling2D(pool_size=(1, 1)))
        model.add(Dropout(0.2))

        model.add(Conv2D(64, (1, 1), padding='valid', activation='relu'))
        model.add(MaxPooling2D(pool_size=(1, 1)))
        model.add(Dropout(0.2))

        model.add(Flatten())
        model.add(Dense(ln, activation='softmax'))

        model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        model.fit(cnn_X_train, Y_train, epochs=2, batch_size=32, verbose=0)
        print(model.summary())
        # pred = model.predict(cnn_X_test)
        pred = arraY_(np.argmax(model.predict(cnn_X_test), axis=-1), axis=0)
        return Confusion_matrix.multi_confu_matrix(Y_test, pred), pred

    def reshape_(data):
            # Convert the data to the appropriate data type (e.g., uint8)
            data_uint8 = (data * 255).astype(np.uint8)
            # Reshape and resize the data
            resized_data = np.zeros((len(data), 32, 32, 1), dtype=np.uint8)
            for i in range(len(data_uint8)):
                img = data_uint8[i].reshape(1, data_uint8.shape[1])  # Reshape each feature for processing
                img_resized = cv2.resize(img, (32, 32))  # Resize the feature to the desired shape
                img_resized_3d = np.repeat(img_resized[:, :, np.newaxis], 1, axis=2)  # Convert to 3 channels
                resized_data[i] = img_resized_3d  # Assign the resized image to the corresponding index in the new array
            return resized_data

    def LeNet_():
        from tensorflow.keras import layers, models
        print("\n LeNet Model")
        x_train = reshape_(X_train)
        x_test = reshape_(X_test)
        input_shape_ = (32, 32, 1)
        y_train = to_categorical(Y_train)#Y_train
        y_test = to_categorical(Y_test)#Y_test
        # Build the LeNet-5 model
        model = models.Sequential()
        # ln = len(y_train[1])

        # define the first set of CONV => ACTIVATION => POOL layers
        model.add(layers.Conv2D(6, (5, 5), activation='relu', input_shape=input_shape_))
        model.add(layers.MaxPooling2D((2, 2)))

        # define the second set of CONV => ACTIVATION => POOL layers
        model.add(layers.Conv2D(16, (5, 5), activation='relu'))
        model.add(layers.MaxPooling2D((2, 2)))

        # define the first FC => ACTIVATION layers
        model.add(layers.Flatten())
        model.add(layers.Dense(120, activation='relu'))
        model.add(layers.Dense(84, activation='relu'))
        # define the second FC layer
        model.add(layers.Dense(ln, activation='softmax'))

        # Compile the model
        model.compile(optimizer='adam',
                      loss='categorical_crossentropy',
                      metrics=['accuracy'])

        # Train the model
        model.fit(x_train, y_train, epochs=1, batch_size=32, validation_split=0.2, verbose=0)
        y_pred = model.predict(x_test)
        y_pred = (y_pred.argmax(axis=-1))
        pred = arraY_(y_pred, axis=4)
        return Confusion_matrix.multi_confu_matrix(Y_test.reshape(-1, 1), pred), pred

    def prop_():
        from Modified_EffViT import Effi_ViT
        pred = arraY_(Effi_ViT(X_train, X_test, Y_train, Y_test), axis=1)
        return Confusion_matrix.multi_confu_matrix(Y_test.reshape(-1, 1), pred), pred

    run = False
    if run:
        print('##~~~~~~Classification process~~~~~~##')
        learn_percent, learning_percentage = [0.6, 0.7, 0.8, 0.9], ['60', '70', '80', '90']
        for lp, lpstr in zip(learn_percent, learning_percentage):
            feat = np.load('FEAT.npy', allow_pickle=True)
            label = np.load('label.npy', allow_pickle=True)
            ln = len(set(label))
            np.save('pre_evaluated/tp', lp)
            feat = np.nan_to_num(feat)
            featt = feat / np.max(feat)
            X_train, X_test, Y_train, Y_test = train_test_split(featt, label.reshape(-1, 1), train_size=lp,
                                                                random_state=0)
            np.save('pre_evaluated/Y_test', Y_test)
            classifier = (ar([prop_(), Bspr1(), Bspr2(), Bilstm(), csqueezenet_(X_train, X_test, Y_train, Y_test),
                              LeNet_(), DCNN(), GoogLeNet_(X_train, X_test, Y_train, Y_test)]))
            metrics = ar([classifier[i][0] for i in range(len(classifier))])
            pred = np.array([classifier[i][1] for i in range(len(classifier))])
            np.save(f'pre_evaluated/pred_label_{lpstr}', pred)
            np.save(f'pre_evaluated/act_label_{lpstr}', Y_test)
            clmn = ['ViT-MENt', 'ResNet50 + KELM', 'CNN + MViT', 'Bi-LSTM', 'Squeezenet', 'Lenet', 'DCNN', 'Googlenet']
            indx = ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR']
            globals()['df_' + lpstr] = pd.DataFrame(metrics.transpose(), columns=clmn, index=indx)

        key = ['60', '70', '80', '90']
        frames = [df_60, df_70, df_80, df_90]
        df1 = pd.concat(frames, keys=key, axis=0)
        df1.to_csv(f'pre_evaluated/Classifier.csv')

        print('# ------Statistical Analysis--------#')
        feat = np.load('FEAT.npy', allow_pickle=True)
        label = np.load('label.npy', allow_pickle=True)
        ln = len(set(label))
        true_lab, pred_label = [], []
        lp = 0.8
        np.save('pre_evaluated/tp', lp)
        for loop in range(10):
            featt = feat / np.max(feat)
            X_train, X_test, Y_train, Y_test, = train_test_split(featt, label, stratify=label, train_size=lp,
                                                                 random_state=0)
            np.save('pre_evaluated/Y_test', Y_test);
            true_lab.append(Y_test);
            np.save('pre_evaluated/tp', lp)
            result = (ar([prop_(), Bspr1(), Bspr2(), Bilstm(), csqueezenet_(X_train, X_test, Y_train, Y_test),
                              LeNet_(), DCNN(), GoogLeNet_(X_train, X_test, Y_train, Y_test)]))
            perf = ar([result[i][0] for i in range(len(result))])
            clmn = ['ViT-MENt', 'ResNet50 + KELM', 'CNN + MViT', 'Bi-LSTM', 'Squeezenet', 'Lenet', 'DCNN', 'Googlenet']
            indx = ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR']
            globals()['df_' + f'{loop}'] = pd.DataFrame(result.transpose(), columns=clmn, index=indx)

        key = np.arange(10).tolist()
        frames = [df_0, df_1, df_2, df_3, df_4, df_5, df_6, df_7, df_8, df_9]
        df = pd.concat(frames, keys=key, axis=0)
        df.to_csv(f'pre_evaluated/StatisticalComparision.csv')

        ablation = ab_comp()

    def line_graph(X, clr=None, index=None, xlabel=None, ylabel=None, case=None):
        plt.style.use('grayscale')
        plt.figure(figsize=(9.5, 6))
        plt.rc('font', weight='bold')
        markers = ['p', '^', 'o', 'd', '>', 'h', 's', 'D']
        # clrs = ['blue', 'r', 'springgreen', 'tab:orange', 'gray', 'tab:brown', 'yellow', 'deeppink']
        for i in range(X.shape[1]):
            plt.plot(X[:, i], color=clr[i], linestyle='solid', linewidth=3,
                     marker=markers[i], markersize=15, label=index[i])  # markerfacecolor=clr[i],
        plt.xlabel(xlabel, fontname='Times New Roman', weight='bold', size=20)
        plt.ylabel(ylabel, fontname='Times New Roman', weight='bold', size=20)
        plt.xticks([r for r in range(4)],
                   ['60', '70', '80', '90'])
        # plt.grid(color='r', linestyle=':', linewidth=0.5)
        plt.subplots_adjust(bottom=0.25)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.4), fontsize=13, ncol=4,
                   frameon=True, framealpha=1, edgecolor='k', fancybox=True)
        plt.xticks(size=14, weight='bold')
        plt.yticks(size=14, weight='bold')
        # plt.grid(True, which='major', axis='both', linestyle='-', linewidth=0.75, zorder=0)
        # plt.grid(True, which='minor', axis='both', linestyle=':', linewidth=0.5, zorder=0)
        for spine in plt.gca().spines.values():
            spine.set_linewidth(3)
        # Enable minor ticks
        plt.minorticks_on()
        plt.savefig(f'Result/version1/{ylabel}.png')

    print('\t\t\t\t\t', Fore.LIGHTYELLOW_EX + 'Results')
    print('\t\t\t\t\t', Fore.LIGHTYELLOW_EX + '*******')

    column = ['ViT-MENt', 'ResNet50 + KELM', 'CNN + MViT', 'Bi-LSTM', 'Squeezenet', 'Lenet', 'DCNN', 'Googlenet']
    plot_result = pd.read_csv(f'pre_evaluated/saved/Classifier.csv', index_col=[0, 1])
    plot_result.columns = column

    key = np.arange(10).tolist()
    df_stat = pd.read_csv(f'pre_evaluated/saved/StatisticalComparision.csv', index_col=[0, 1])
    stat = df_stat.loc[(key, ['Accuracy']), :].values
    stat = stat_analysis(stat).transpose()
    df_ = pd.DataFrame(stat, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['ViT-MENt', 'ResNet50 + KELM', 'CNN + MViT', 'Bi-LSTM', 'Squeezenet', 'Lenet', 'DCNN',
                        'Googlenet'])
    df_.to_csv(f'pre_evaluated/saved/statistical analysis.csv')

    print('\n\t\t\t\t\t', Fore.LIGHTRED_EX + 'Statistical Feature-Accuracy ')
    print('\t\t\t\t\t', Fore.LIGHTRED_EX + '******************* ')
    df_.to_csv(f'Result/version1/statistical analysis_Accuracy.csv')
    print(df_.to_markdown())

    print('\n\t\t\t\t\t', Fore.LIGHTGREEN_EX + 'Ablation Analysis-80% ')
    print('\t\t\t\t\t', Fore.LIGHTGREEN_EX + '***************** ')
    ab = pd.read_csv(f'pre_evaluated/saved/ablation.csv', index_col=[0])
    ab.to_csv(f'Result/version1/Ablation_80%.csv')
    print(ab.to_markdown())

    print('\n\t\t\t\t\t', Fore.LIGHTGREEN_EX + 'Preprocessing Table')
    print('\t\t\t\t\t', Fore.LIGHTGREEN_EX + '*******************')
    ab = pd.read_csv(f'pre_evaluated/saved/preprocessing_comp.csv', index_col=[0])
    ab.to_csv(f'Result/version1/preprocessing_result.csv')
    print(ab.to_markdown())

    print('\n\t\t\t\t\t', Fore.LIGHTGREEN_EX + 'Segmentation Table')
    print('\t\t\t\t\t', Fore.LIGHTGREEN_EX + '******************')
    ab = pd.read_csv(f'pre_evaluated/saved/Segmentation.csv', index_col=[0])
    ab.to_csv(f'Result/version1/segmentation_result.csv')
    print(ab.to_markdown())

    indx = ['Sensitivity', 'Specificity', 'Accuracy', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR']

    for i in range(60, 91, 10):
        avg = plot_result.loc[i, :]
        avg.reset_index(drop=True, level=0)
        avg.to_csv(f'Result/' + str(i) + '.csv')
        print('\n\t', Fore.MAGENTA + str(i))
        print(avg.to_markdown())

    # Analysis plot
    for idx, jj in enumerate(indx):
        colors = ['r', 'c', 'tab:pink', 'darkgreen', 'tab:olive', 'tomato', 'navy', 'tab:brown']
        new_ = plot_result.loc[([60, 70, 80, 90], [jj]), :]
        new_.reset_index(drop=True, level=1, inplace=True)
        new = new_.values
        line_graph(new, clr=colors, index=column, xlabel='Training Data(%)',
                   ylabel=indx[idx])

    plt.show()


init(autoreset=True)
popup.popup(full_analysis, result.result)